Clazz.declarePackage ("javajs.api");
c$ = Clazz.declareInterface (javajs.api, "GenericCifDataParser");
Clazz.defineStatics (c$,
"NONE", -1);
