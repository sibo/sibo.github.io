Clazz.declareInterface(java.util,"RandomAccess");
