Clazz.load(["java.util.Iterator"],"java.util.ListIterator",null,function(){
Clazz.declareInterface(java.util,"ListIterator",java.util.Iterator);
});
