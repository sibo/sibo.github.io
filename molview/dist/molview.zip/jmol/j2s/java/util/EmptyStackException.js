Clazz.load(["java.lang.RuntimeException"],"java.util.EmptyStackException",null,function(){
c$=Clazz.declareType(java.util,"EmptyStackException",RuntimeException);
});
