Clazz.load(["java.lang.VirtualMachineError"],"java.lang.InternalError",null,function(){
c$=Clazz.declareType(java.lang,"InternalError",VirtualMachineError);
});
