Clazz.load(["java.io.IOException"],"java.io.FileNotFoundException",null,function(){
c$=Clazz.declareType(java.io,"FileNotFoundException",java.io.IOException);
});
