Clazz.load(["java.io.ObjectStreamException"],"java.io.NotActiveException",null,function(){
c$=Clazz.declareType(java.io,"NotActiveException",java.io.ObjectStreamException);
});
